<?php
class Pessoa {
    private $nome;
    private $idade;
    private $endereco;
    
    public function __construct($nome, $idade, $endereco) {
        $this->nome = $nome;
        $this->idade = $idade;
        $this->endereco = $endereco;
    }
    
    public function getNome() {
        return $this->nome;
    }
    
    public function getIdade() {
        return $this->idade;
    }
    
    public function getEndereco() {
        return $this->endereco;
    }
    
    public function apresentar() {
        echo "Nome: " . $this->getNome() . "<br>";
        echo "Idade: " . $this->getIdade() . " anos<br>";
        echo "Endereço: " . $this->getEndereco() . "<br><br>";
    }
}

// Criando cinco objetos do tipo Pessoa
$pessoa1 = new Pessoa('João', 30, 'Rua A, 123');
$pessoa2 = new Pessoa('Maria', 25, 'Avenida B, 456');
$pessoa3 = new Pessoa('Carlos', 40, 'Rua C, 789');
$pessoa4 = new Pessoa('Ana', 35, 'Rua D, 321');
$pessoa5 = new Pessoa('Pedro', 28, 'Avenida E, 654');

// Apresentando as informações das cinco pessoas
echo "Informações das Pessoas:<br><br>";
$pessoa1->apresentar();
$pessoa2->apresentar();
$pessoa3->apresentar();
$pessoa4->apresentar();
$pessoa5->apresentar();
?>