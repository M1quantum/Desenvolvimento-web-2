<?php

include 'tools.php';

echo quadrado(4);

?>