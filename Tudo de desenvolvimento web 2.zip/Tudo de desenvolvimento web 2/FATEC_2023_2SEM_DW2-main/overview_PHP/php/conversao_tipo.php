<?php

var_dump('teste'. 5);
echo '<br>';
var_dump('5'+'10');
?>