<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passagem de Parâmetros via POST</title>
</head>
<body>
    <form action="parametros_post_02.php" method="post">
        <label for="fname">Primeiro Nome:</label>
        <input type="text" id="fname" name="fname"><br><br>
        <label for="lname">Sobrenome:</label>
        <input type="text" id="lname" name="lname"><br><br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>
