<?php
class SalaVirtual {
    private $nomeSala;
    private $capacidade;
    private $participantes;

    public function __construct($nomeSala, $capacidade) {
        $this->nomeSala = $nomeSala;
        $this->capacidade = $capacidade;
        $this->participantes = [];
    }

    public function getNomeSala() {
        return $this->nomeSala;
    }

    public function getCapacidade() {
        return $this->capacidade;
    }

    public function adicionarParticipante($participante) {
        if (count($this->participantes) < $this->capacidade) {
            $this->participantes[] = $participante;
            echo "Participante '{$participante}' adicionado à sala '{$this->nomeSala}'.<br>";
        } else {
            echo "A sala '{$this->nomeSala}' está cheia. Não é possível adicionar mais participantes.<br>";
        }
    }

    public function listarParticipantes() {
        echo "Participantes da sala '{$this->nomeSala}':<br>";
        foreach ($this->participantes as $participante) {
            echo "- {$participante}<br>";
        }
        echo "<br>";
    }
}

// Criando duas salas virtuais
$sala1 = new SalaVirtual('Sala A', 10);
$sala2 = new SalaVirtual('Sala B', 5);

// Adicionando participantes às salas
$sala1->adicionarParticipante('João');
$sala1->adicionarParticipante('Maria');
$sala1->adicionarParticipante('Carlos');
$sala2->adicionarParticipante('Ana');
$sala2->adicionarParticipante('Pedro');
$sala2->adicionarParticipante('Lucas');
$sala2->adicionarParticipante('Sofia');

// Listando os participantes das salas
$sala1->listarParticipantes();
$sala2->listarParticipantes();

?>