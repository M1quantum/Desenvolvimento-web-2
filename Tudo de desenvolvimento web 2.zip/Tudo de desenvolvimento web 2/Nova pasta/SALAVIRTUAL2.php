<?php
class SalaVirtual {
    private $nomeSala;
    private $capacidade;
    private $professor;

    public function __construct($nomeSala, $capacidade, $professor) {
        $this->nomeSala = $nomeSala;
        $this->capacidade = $capacidade;
        $this->professor = $professor;
    }

    public function getNomeSala() {
        return $this->nomeSala;
    }

    public function getCapacidade() {
        return $this->capacidade;
    }

    public function getProfessor() {
        return $this->professor;
    }

    public function listarParticipantes() {
        echo "Sala '{$this->nomeSala}':<br>";
        echo "Professor: {$this->getProfessor()}<br>";
        echo "Capacidade: {$this->capacidade} participantes<br><br>";
    }
}

// Criando duas salas virtuais com professores
$sala1 = new SalaVirtual('DESENVOLVIMENTO WEB 2', 10, 'Prof. Orlando');
$sala2 = new SalaVirtual('BANCO DE DADOS RELACIONAL', 5, 'Prof. Nilton');

// Listando informações das salas, incluindo o professor
$sala1->listarParticipantes();
$sala2->listarParticipantes();


?>